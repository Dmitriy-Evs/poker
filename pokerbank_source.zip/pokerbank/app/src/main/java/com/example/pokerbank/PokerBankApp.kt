package com.example.pokerbank

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PokerBankApp : Application()
