package com.example.pokerbank

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PokerViewModel @Inject constructor(
    private val repo: PokerRepository
) : ViewModel() {

    val players = repo.players
    private val _exchangeRate = MutableStateFlow(1.0)
    val exchangeRate: StateFlow<Double> = _exchangeRate.asStateFlow()

    private val _showingAddPlayer = MutableStateFlow(false)
    val showingAddPlayer: Boolean get() = _showingAddPlayer.value

    var pendingTransaction: Pair<Player, String>? = null
        private set

    fun showAddPlayerDialog() { _showingAddPlayer.value = true }
    fun dismissDialogs() { _showingAddPlayer.value = false; pendingTransaction = null }

    fun addPlayer(name: String) {
        viewModelScope.launch { repo.addPlayer(name) }
    }

    fun startTransaction(player: Player, type: String) {
        pendingTransaction = player to type
    }

    fun commitTransaction(player: Player, chips: Int, type: String) {
        if (chips <= 0) return
        viewModelScope.launch {
            repo.addTransaction(player, chips, type, _exchangeRate.value)
        }
    }

    fun setExchangeRate(rate: Double) { _exchangeRate.value = rate }
}
