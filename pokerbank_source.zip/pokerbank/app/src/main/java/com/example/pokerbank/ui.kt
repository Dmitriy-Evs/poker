package com.example.pokerbank

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.collectLatest

@Composable
fun PokerBankAppScreen(viewModel: PokerViewModel = viewModel()) {
    val players by viewModel.players.collectAsState(initial = emptyList())
    val exchangeRate by viewModel.exchangeRate.collectAsState(1.0)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { viewModel.showAddPlayerDialog() }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Text(
                "Курс: 1 фишка = %.2f ед.".format(exchangeRate),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(16.dp)
            )
            LazyColumn {
                items(players) { player ->
                    PlayerRow(player, viewModel)
                }
            }
        }
    }

    if (viewModel.showingAddPlayer) {
        AddPlayerDialog(
            onAdd = { name -> viewModel.addPlayer(name) },
            onDismiss = { viewModel.dismissDialogs() }
        )
    }

    viewModel.pendingTransaction?.let { (player) ->
        TransactionDialog(
            player = player,
            onConfirm = { chips, type -> viewModel.commitTransaction(player, chips, type) },
            onDismiss = { viewModel.dismissDialogs() }
        )
    }
}

@Composable
fun PlayerRow(player: Player, viewModel: PokerViewModel) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(player.name, style = MaterialTheme.typography.titleMedium)
                Text("Фишки: ${player.chips}")
            }
            Button(onClick = { viewModel.startTransaction(player, "BUY") }) {
                Text("Докупка")
            }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { viewModel.startTransaction(player, "CASH_OUT") }) {
                Text("Вывод")
            }
        }
    }
}

@Composable
fun AddPlayerDialog(onAdd: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить игрока") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Имя") }
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onAdd(name)
                    onDismiss()
                },
                enabled = name.isNotBlank()
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun TransactionDialog(
    player: Player,
    onConfirm: (Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var chips by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Транзакция для ${player.name}") },
        text = {
            OutlinedTextField(
                value = chips,
                onValueChange = { chips = it.filter { c -> c.isDigit() } },
                label = { Text("Количество фишек") }
            )
        },
        confirmButton = {
            Column {
                TextButton(
                    onClick = {
                        onConfirm(chips.toIntOrNull() ?: 0, "BUY")
                        onDismiss()
                    },
                    enabled = chips.isNotBlank()
                ) { Text("Докупка") }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(
                    onClick = {
                        onConfirm(chips.toIntOrNull() ?: 0, "CASH_OUT")
                        onDismiss()
                    },
                    enabled = chips.isNotBlank()
                ) { Text("Вывод") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
