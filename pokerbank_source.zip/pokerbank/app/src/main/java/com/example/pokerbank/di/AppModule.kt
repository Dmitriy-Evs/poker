package com.example.pokerbank.di

import android.content.Context
import androidx.room.Room
import com.example.pokerbank.PokerDao
import com.example.pokerbank.PokerDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PokerDatabase =
        Room.databaseBuilder(context, PokerDatabase::class.java, "poker.db").build()

    @Provides
    fun provideDao(db: PokerDatabase): PokerDao = db.dao()
}
