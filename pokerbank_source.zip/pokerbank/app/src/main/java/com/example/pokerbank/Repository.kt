package com.example.pokerbank

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PokerRepository @Inject constructor(private val dao: PokerDao) {

    val players: Flow<List<Player>> = dao.players()

    suspend fun addPlayer(name: String) {
        dao.insertPlayer(Player(name = name))
    }

    suspend fun changeChips(player: Player, delta: Int) {
        dao.updatePlayer(player.copy(chips = player.chips + delta))
    }

    suspend fun addTransaction(player: Player, delta: Int, type: String, rate: Double) {
        dao.insertTransaction(
            Transaction(
                playerId = player.id,
                type = type,
                amountChips = delta,
                amountCurrency = (delta * rate).toInt()
            )
        )
        changeChips(player, if (type == "BUY") delta else -delta)
    }
}
