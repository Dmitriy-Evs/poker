package com.example.pokerbank

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Player(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val chips: Int = 0
)

@Entity(indices = [Index("playerId")])
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playerId: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "BUY",
    val amountChips: Int = 0,
    val amountCurrency: Int = 0
)

@Dao
interface PokerDao {
    @Insert suspend fun insertPlayer(player: Player): Long
    @Update suspend fun updatePlayer(player: Player)
    @Delete suspend fun deletePlayer(player: Player)
    @Query("SELECT * FROM Player") fun players(): Flow<List<Player>>

    @Insert suspend fun insertTransaction(tx: Transaction)
    @Query("SELECT * FROM Transaction ORDER BY timestamp DESC")
    fun transactions(): Flow<List<Transaction>>
}

@Database(entities = [Player::class, Transaction::class], version = 1)
abstract class PokerDatabase : RoomDatabase() {
    abstract fun dao(): PokerDao
}
